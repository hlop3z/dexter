## Install **build**
```sh
pip install -q build
```

## Build **Package**
```sh
python -m build
```

## Install **Package**
```sh
python -m pip install dist/{mylib}-0.0.1.tar.gz
```

## ReCreate
```sh
python -m build && pip uninstall -y dexter && pip install dist/dexter-0.0.1-py2.py3-none-any.whl && python -m dexter
```

## ReCreate
```sh
python -m build && pip install dist/dexter-0.0.1-py2.py3-none-any.whl && python -m dexter
```
